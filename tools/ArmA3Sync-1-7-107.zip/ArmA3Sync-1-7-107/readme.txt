ArmA3Sync - launcher and addons synchronizer for ArmA 3 
By the [S.o.E] team, www.sonsofexiled.fr (2013-2022)

Authors
-------
[S.o.E] Major_Shepard (software development)
[S.o.E] Matt2507 (graphical design)
[S.o.E], [BWF] & [F27] team members (testing)

This software is inspired from:
- ArmA 2 Game Launcher by SpiritedMachine.
- AddonSync 2009 by Yoma. 

[S.o.E] team, www.sonsofexiled.fr
[BWF]  team, http://www.blackwater.fr
[F27]  team, http://www.force27.com

Licence
-------
ArmA3Sync is free software and agree the GNU Global Public Licence (GPL) in version 3.Authors and the [S.o.E] team reject any responsability in the use of this software. For non commercial purpose.

Requirements
------------
-Java Runtime Environment 8 or higher
-Windows 32/64 bit XP/Vista/7/8/10, Linux like plateforms with a graphical interface.

Installation 
------------
1. Install the Java Runtime Environment: http://www.oracle.com/technetwork/java/javase/downloads/index.html.
2. Run ArmA3Sync.exe or ArmA3Sync.bat or ArmA3Sync.sh.

Documentation
-------------
Look to the ArmA3Sync Wiki at www.sonsofexiled.fr

