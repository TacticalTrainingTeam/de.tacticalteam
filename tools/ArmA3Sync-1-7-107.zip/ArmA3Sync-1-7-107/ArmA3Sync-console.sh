#sh
java -Djava.net.preferIPv4Stack=true -Xms256m -Xmx256m -jar ArmA3Sync.jar -console